package com.example.recyclerviewexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerlist = (RecyclerView)findViewById(R.id.recyclerlist);
        recyclerlist.setLayoutManager(new LinearLayoutManager(this));
        String[] texts={"Java","Javascript","C","C++","Data Structure",
                ".net","openGl","python","html","xml","php","Java","Javascript","C","C++","Data Structure",
                ".net","openGl","python","html","xml","php"};
        recyclerlist.setAdapter(new DataAdapter(texts));
    }
}
