package com.example.recyclerviewexamplemain;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    ArrayList<ModelShopping> shoppingList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.rv);
        shoppingList=new ArrayList<>();
        shoppingList.add(new ModelShopping(R.drawable.sh2,"Dress","Womens","$14"));
        shoppingList.add(new ModelShopping(R.drawable.sh3,"Dress","Kid","$24"));
        shoppingList.add(new ModelShopping(R.drawable.sh4,"Dress","Girl","$16"));
        shoppingList.add(new ModelShopping(R.drawable.sh5,"Dress","Men","$15"));
        shoppingList.add(new ModelShopping(R.drawable.sh6,"Shoe","Men","$18"));
        shoppingList.add(new ModelShopping(R.drawable.sh7,"Shoe","Women","$17"));
        shoppingList.add(new ModelShopping(R.drawable.sh2,"Dress","Womens","$14"));
        shoppingList.add(new ModelShopping(R.drawable.sh3,"Dress","Kid","$24"));
        shoppingList.add(new ModelShopping(R.drawable.sh4,"Dress","Girl","$16"));
        shoppingList.add(new ModelShopping(R.drawable.sh5,"Dress","Men","$15"));
        shoppingList.add(new ModelShopping(R.drawable.sh6,"Shoe","Men","$18"));
        shoppingList.add(new ModelShopping(R.drawable.sh7,"Shoe","Women","$17"));

        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        RecyclerView.LayoutManager rvLilayoutManager= layoutManager;

        recyclerView.setLayoutManager(rvLilayoutManager);
        ShoppingAdapter adapter=new ShoppingAdapter(this,shoppingList);
        recyclerView.setAdapter(adapter);

    }
}
