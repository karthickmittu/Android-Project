package com.example.recyclerviewexample;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder>
{
    private String[] data;
    //This gives the data can be showed in the Recycler view//
    public DataAdapter(String[] data)
    {
        this.data=data;
    }

    //Creates the view holder and stores the view inside it //
    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.list_item_layout,parent,false);
        return new DataViewHolder(view);
    }


    //Binds the data with the view holder//
    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position)
    {
        String title=data[position];
        holder.txt.setText(title);
    }

    @Override
    public int getItemCount()
    {
        return data.length;
    }

    public class DataViewHolder extends RecyclerView.ViewHolder
    {
        ImageView img;
        TextView txt;
        public DataViewHolder(@NonNull View itemView)
        {
            super(itemView);
            img=(ImageView) itemView.findViewById(R.id.image1);
            txt=(TextView) itemView.findViewById(R.id.text1);
        }
    }
}
